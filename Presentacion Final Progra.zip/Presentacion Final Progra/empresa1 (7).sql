-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-09-2022 a las 04:57:46
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `empresa1`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `codigo` int(6) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  `nit` varchar(8) DEFAULT NULL,
  `dpi` varchar(8) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `ciudad` varchar(30) DEFAULT NULL,
  `postal` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`codigo`, `nombre`, `nit`, `dpi`, `correo`, `telefono`, `ciudad`, `postal`) VALUES
(1, 'Elías Martínez', '12345678', '87654321', 'ali@gmail.com', '55679832', 'Mazatenango', '10001'),
(2, 'Estuardo Pérez', '33447788', '89652001', 'estuardo@gmail.com', '22455678', 'Mazatenango', '10001'),
(3, 'Emanuel Gonzáles', '44456788', '22344378', 'gironem@gmail.com', '01011243', 'Mazatenango', '10001'),
(4, 'Carol Baldetti', '34450001', '10016556', 'carol@gmail.com', '22343444', 'San Antonio', '10010'),
(5, 'Feliciano Pérez', '22344355', '11210001', 'felix2@gmail.com', '33340012', 'San Gabriel', '10012'),
(6, 'Carlos Antonio', '33445665', '22234456', 'carlos@gmail.com', '22345678', 'Mazatenango', '10001'),
(7, 'Juan Cobox', '00012234', '77789889', 'juancaballo@gmail.com', '23345665', 'Mazatenango', '10001'),
(8, 'waldir Castillo', '12345699', '12345666', 'waldir@gmail.com', '22222222', 'Mazatenango', '10001'),
(9, 'Gabriela ávila', '09900011', '01010101', 'gaby@gmail.com', '13232222', 'Samayac', '10020'),
(10, 'Claidia Cifuentes', '02347899', '10000082', 'Clau@gmail.com', '23344451', 'Mazatenango', '10001'),
(11, 'Ferchis Bebis', '1104117K', '11111111', 'ferchis@gmail.com', '12345678', 'Mazatenango', '10001'),
(12, 'Amy Vasquez', '12345678', '12345678', 'amy@gmail.com', '12345678', 'Mazatenago', '10001'),
(13, 'Ana Laura', '20000008', '23980576', 'Anis@gmail.com', '09905624', 'Mazatenango', '10001'),
(14, 'andre', '432423', '32432', 'adawd', '1312', 'dawaw', '1233');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes1`
--

CREATE TABLE `clientes1` (
  `codigo` int(30) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  `nit` varchar(30) DEFAULT NULL,
  `dpi` varchar(30) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `ciudad` varchar(30) DEFAULT NULL,
  `postal` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `clientes1`
--

INSERT INTO `clientes1` (`codigo`, `nombre`, `nit`, `dpi`, `correo`, `telefono`, `ciudad`, `postal`) VALUES
(1, 'ejemplo', '12345678', '87654321', 'ejemplo@gmail.com', '22334455', 'Mazatenango', '10001'),
(2, 'ejemplo2', '11223344', '88776655', 'ejemplo2@gmail.com', '12345678', 'Mazatenango', '10001');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inicio`
--

CREATE TABLE `inicio` (
  `nombre` varchar(30) NOT NULL,
  `usuario` varchar(30) DEFAULT NULL,
  `contraseña` varchar(30) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `nivel` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `inicio`
--

INSERT INTO `inicio` (`nombre`, `usuario`, `contraseña`, `correo`, `telefono`, `nivel`) VALUES
('Ashton', 'ashton123', '567', 'qeqe', 'qweqw', 'cajero'),
('Diego Aj', 'diego123', '123', 'daav@gmail.com', '23545678', 'cajero'),
('Guillermo Lopez', 'guille123', '456', 'gl@gmail.com', '23435678', 'propietario'),
('Mels demoledora', 'mels123', '123', 'mels@gmail.com', '56157885', 'subgerente'),
('Misael Paredes', 'misael123', '123', 'paredes@gmail.com', '55556677', 'vendedor'),
('nathy', 'nath123', '123', 'ndelvalle217@gmail.com', '33379546', 'subgerente'),
('Oscar Armas', 'oscar123', '123', 'nemo@gmail.com', '78093322', 'propietario'),
('Scarlett Fernanda', 'ferchis123', '123', '1608scarlettveloso@gmail.com', '54784510', 'subgerente'),
('Sergio Quan', 'sergio123', '123', 'sergi@gmail.com', '00001122', 'subgerente'),
('Waldir Pérez', 'waldir123', '123', 'wcm@gmail.com', '34568722', 'gerente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prodsucursal1`
--

CREATE TABLE `prodsucursal1` (
  `codigo` int(30) NOT NULL,
  `producto` varchar(30) DEFAULT NULL,
  `precio` varchar(30) DEFAULT NULL,
  `cantidad` varchar(30) DEFAULT NULL,
  `categoria` varchar(30) DEFAULT NULL,
  `proveedor` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `prodsucursal1`
--

INSERT INTO `prodsucursal1` (`codigo`, `producto`, `precio`, `cantidad`, `categoria`, `proveedor`) VALUES
(1, 'Caja Coca Lata', '71', '223', 'Gaseosa', 'Estuardo Jeréz'),
(2, 'Caja Coca Desechable 355ml', '125', '195', 'Gaseosa', 'Estuardo Jeréz'),
(3, 'Caja Coca Desechable 600ml', '170', '200', 'Gaseosa', 'Estuardo Jeréz'),
(4, 'Caja Coca Desechable 750ml', '185', '200', 'Gaseosa', 'Estuardo Jeréz'),
(5, 'Caja Coca Vidrio 500ml', '130', '151', 'Gaseosa', 'Estuardo Jeréz'),
(6, 'Caja Coca Vidrio 1 L', '110', '278', 'Gaseosa', 'Estuardo Jeréz'),
(7, 'Caja Pepsi Lata', '62', '195', 'Gaseosa', 'Enrique Gonzáles'),
(8, 'Caja Pepsi Desechable 355ml', '122', '228', 'Gaseosas', 'Enrique Gonzáles'),
(9, 'Caja Pepsi Desechable 600ml', '172', '93', 'Gaseosa', 'Enrique Gonzáles'),
(10, 'Caja Pepsi Jumbo 3L', '96', '100', 'Gaseosa', 'Enrique Gonzáles');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prodsucursal2`
--

CREATE TABLE `prodsucursal2` (
  `codigo` int(30) NOT NULL,
  `producto` varchar(30) DEFAULT NULL,
  `precio` varchar(30) DEFAULT NULL,
  `cantidad` varchar(30) DEFAULT NULL,
  `categoria` varchar(30) DEFAULT NULL,
  `proveedor` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `prodsucursal2`
--

INSERT INTO `prodsucursal2` (`codigo`, `producto`, `precio`, `cantidad`, `categoria`, `proveedor`) VALUES
(1, 'Unidad Coca Lata', '5', '46', 'Gaseosa', 'Héctor Salazar'),
(2, 'Unidad Coca Desechable 355ml', '5.50', '41', 'Gaseosa', 'Héctor Salazar'),
(3, 'Unidad Coca Desechable 600ml', '7.50', '28', 'Gaseosa', 'Héctor Salazar'),
(4, 'Unidad Coca Jumbo 2.5L', '16', '37', 'Gaseosa', 'Héctor Salazar'),
(5, 'Unidad Coca Vidrio 500ml', '6', '29', 'Gaseosa', 'Héctor Salazar'),
(6, 'Unidad Coca Vidrio 1L', '9', '13', 'Gaseosa', 'Héctor Salazar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prodsucursal3`
--

CREATE TABLE `prodsucursal3` (
  `codigo` int(30) NOT NULL,
  `producto` varchar(30) DEFAULT NULL,
  `precio` varchar(30) DEFAULT NULL,
  `cantidad` varchar(30) DEFAULT NULL,
  `categoria` varchar(30) DEFAULT NULL,
  `proveedor` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `prodsucursal3`
--

INSERT INTO `prodsucursal3` (`codigo`, `producto`, `precio`, `cantidad`, `categoria`, `proveedor`) VALUES
(1, 'U. XL Blanco 750ml', '45', '46', 'Licor', 'Mario Jiménez'),
(2, 'U. XL Blanco 500ml', '25', '50', 'Licor', 'Mario Jiménez'),
(3, 'U. XL S. Piña y Coco 750ml', '50', '30', 'Licor', 'Mario Jiménez'),
(4, 'U. XL S. Piña y Coco 500ml', '32', '23', 'Licor', 'Mario Jiménez'),
(5, 'U. XL S. Sourl Blast 750ml', '50', '38', 'Licor', 'Mario Jiménez'),
(6, 'U. XL S. Sourl Blast 500ml', '32', '34', 'Licor', 'Mario Jiménez'),
(7, 'U. XL S. Sandía 750ml', '50', '46', 'Licor', 'Mario Jiménez'),
(8, 'U. XL S. Sandía 500ml', '32', '36', 'Licor', 'Mario Jiménez');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventasrealizadas`
--

CREATE TABLE `ventasrealizadas` (
  `codigo` int(30) NOT NULL,
  `cliente` varchar(30) DEFAULT NULL,
  `vendedor` varchar(30) DEFAULT NULL,
  `fecha` varchar(30) DEFAULT NULL,
  `total` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ventasrealizadas`
--

INSERT INTO `ventasrealizadas` (`codigo`, `cliente`, `vendedor`, `fecha`, `total`) VALUES
(1, 'Elías Martínez', 'EL MANANTIAL', '09-16-2022 11:21:59', '2447.2'),
(2, 'Estuardo Pérez', 'EL MANANTIAL', '09-16-2022 02:20:41', '1545.6'),
(3, 'Elías Martínez', 'EL MANANTIAL', '09-16-2022 02:22:40', '795.2'),
(12, 'Juan Cobox', 'EL MANANTIAL', '09-17-2022 06:47:34', '444.64'),
(13, 'Elías Martínez', 'EL MANANTIAL', '09-17-2022 08:12:45', '1404.48'),
(14, 'waldir Castillo', 'EL MANANTIAL', '09-17-2022 08:18:56', '159.04'),
(15, 'Gabriela ávila', 'EL MANANTIAL', '09-17-2022 09:02:07', '655.2'),
(16, 'Claidia Cifuentes', 'EL MANANTIAL', '09-18-2022 12:56:55', '6849.92'),
(17, 'Claidia Cifuentes', 'EL MANANTIAL', '09-18-2022 01:00:55', '159.04'),
(18, 'Ferchis Bebis', 'EL MANANTIAL', '09-18-2022 10:24:58', '683.2'),
(19, 'Amy Vasquez', 'EL MANANTIAL', '09-19-2022 10:18:41', '705.6'),
(20, 'Ana Laura', 'EL MANANTIAL', '09-19-2022 12:43:59', '1258.88'),
(21, 'Carol Baldetti', 'EL MANANTIAL', '09-19-2022 01:15:47', '828.8'),
(22, 'andre', 'EL MANANTIAL', '09-20-2022 09:30:15', '546.56'),
(23, 'Emanuel Gonzáles', 'EL MANANTIAL', '09-20-2022 09:35:26', '190.4'),
(24, 'Elías Martínez', 'EL MANANTIAL', '09-20-2022 07:53:57', '2164.96');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventasrealizadas2`
--

CREATE TABLE `ventasrealizadas2` (
  `codigo` int(30) NOT NULL,
  `cliente` varchar(30) DEFAULT NULL,
  `vendedor` varchar(30) DEFAULT NULL,
  `fecha` varchar(30) DEFAULT NULL,
  `total` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ventasrealizadas2`
--

INSERT INTO `ventasrealizadas2` (`codigo`, `cliente`, `vendedor`, `fecha`, `total`) VALUES
(1, 'Carol Baldetti', 'EL BOSQUE VERDE', '09-16-2022 08:48:52', '29.12'),
(3, 'Emanuel Gonzáles', 'EL BOSQUE VERDE', '09-20-2022 07:35:16', '20.16'),
(4, 'Emanuel Gonzáles', 'EL BOSQUE VERDE', '09-20-2022 07:53:09', '35.84'),
(5, 'Elías Martínez', 'EL BOSQUE VERDE', '09-20-2022 08:06:54', '10.08'),
(6, 'Amy Vasquez', 'EL BOSQUE VERDE', '09-20-2022 08:19:43', '315.84');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventasrealizadas3`
--

CREATE TABLE `ventasrealizadas3` (
  `codigo` int(30) NOT NULL,
  `cliente` varchar(30) DEFAULT NULL,
  `vendedor` varchar(30) DEFAULT NULL,
  `fecha` varchar(30) DEFAULT NULL,
  `total` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ventasrealizadas3`
--

INSERT INTO `ventasrealizadas3` (`codigo`, `cliente`, `vendedor`, `fecha`, `total`) VALUES
(1, 'Carlos Antonio', 'SMARATTO', '09-16-2022 09:19:16', '224'),
(2, 'Elías Martínez', 'SMARATTO', '09-20-2022 07:37:17', '250.88'),
(3, 'Feliciano Pérez', 'SMARATTO', '09-20-2022 07:48:01', '143.36'),
(4, 'Estuardo Pérez', 'SMARATTO', '09-20-2022 07:51:50', '100.8'),
(6, 'Emanuel Gonzáles', 'SMARATTO', '09-20-2022 07:57:18', '35.84');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `inicio`
--
ALTER TABLE `inicio`
  ADD PRIMARY KEY (`nombre`);

--
-- Indices de la tabla `prodsucursal1`
--
ALTER TABLE `prodsucursal1`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `prodsucursal2`
--
ALTER TABLE `prodsucursal2`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `prodsucursal3`
--
ALTER TABLE `prodsucursal3`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `ventasrealizadas`
--
ALTER TABLE `ventasrealizadas`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `ventasrealizadas2`
--
ALTER TABLE `ventasrealizadas2`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `ventasrealizadas3`
--
ALTER TABLE `ventasrealizadas3`
  ADD PRIMARY KEY (`codigo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `codigo` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `prodsucursal1`
--
ALTER TABLE `prodsucursal1`
  MODIFY `codigo` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `prodsucursal2`
--
ALTER TABLE `prodsucursal2`
  MODIFY `codigo` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `prodsucursal3`
--
ALTER TABLE `prodsucursal3`
  MODIFY `codigo` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `ventasrealizadas`
--
ALTER TABLE `ventasrealizadas`
  MODIFY `codigo` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de la tabla `ventasrealizadas2`
--
ALTER TABLE `ventasrealizadas2`
  MODIFY `codigo` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `ventasrealizadas3`
--
ALTER TABLE `ventasrealizadas3`
  MODIFY `codigo` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
